package com.example.limbosignal

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val captureRequest = 9001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32,32,32,32)
        }
        root.addView(TextView(this).apply {
            text = "Limbo Signal"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Automatic reader tuned to the supplied Limbo screen. It watches the large center multiplier and waits for the rapidly changing value to settle before recording a result."
            textSize = 15f
            setPadding(0,16,0,22)
        })
        val overlay = Button(this).apply { text = "Grant overlay permission" }
        val start = Button(this).apply { text = "Start automatic reader" }
        val stop = Button(this).apply { text = "Stop reader" }

        overlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant overlay permission first.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
        }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)) }

        root.addView(overlay)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            })
            Toast.makeText(this, "Reader started — switch to Chrome or Firefox.", Toast.LENGTH_LONG).show()
        }
    }
}
