package com.example.limbosignal

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.TextRecognition
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.*

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TextView? = null
    private var recognizer: TextRecognizer? = null
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val results = mutableListOf<Double>()

    // Transient-result handling:
    // OCR can see several rapidly flashing values after Bet. We don't record
    // those immediately. A candidate must remain unchanged for SETTLE_MS,
    // or be observed repeatedly, before it becomes the official result.
    private var pendingValue: Double? = null
    private var pendingSince = 0L
    private var pendingHits = 0
    private var lastCommitted: Double? = null
    private var lastFrameAt = 0L

    companion object {
        private const val SETTLE_MS = 260L
        private const val MIN_FRAME_GAP_MS = 75L
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            "limbo_capture", "Limbo reader", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        startForeground(
            7,
            NotificationCompat.Builder(this, "limbo_capture")
                .setContentTitle("Limbo Signal")
                .setContentText("Reading the Limbo screen")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        )
        recognizer = TextRecognition.getClient()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", 0) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(Looper.getMainLooper()))
        startCapture()
        showOverlay()
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val density = dm.densityDpi

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ ir ->
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < MIN_FRAME_GAP_MS) {
                ir.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastFrameAt = now

            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * w

            val full = Bitmap.createBitmap(
                w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)
            image.close()

            // Based on the supplied 945x2048 screenshots:
            // live multiplier occupies the central game-card area around
            // x=16%..84%, y=22%..39%. Keep a generous crop for scaling.
            val left = (full.width * 0.14f).toInt().coerceAtLeast(0)
            val top = (h * 0.22f).toInt().coerceAtLeast(0)
            val right = (full.width * 0.86f).toInt().coerceAtMost(full.width)
            val bottom = (h * 0.39f).toInt().coerceAtMost(full.height)

            val crop = Bitmap.createBitmap(full, left, top, right-left, bottom-top)
            full.recycle()

            val imageInput = InputImage.fromBitmap(crop, 0)
            recognizer?.process(imageInput)
                ?.addOnSuccessListener(ocrExecutor) { text ->
                    extractCandidate(text.text)
                }
                ?.addOnCompleteListener(ocrExecutor) {
                    crop.recycle()
                }
        }, Handler(Looper.getMainLooper()))

        display = projection!!.createVirtualDisplay(
            "LimboSignal", w, h, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
    }

    private fun extractCandidate(raw: String) {
        val cleaned = raw
            .replace('×', 'x')
            .replace(',', '.')
            .replace(Regex("[\n\r]"), " ")

        // Require the characteristic x suffix. This excludes the wallet,
        // target, bet amount, profit and most other UI numbers.
        val regex = Regex("""(?<![\d.])(\d{1,7}(?:\.\d{1,4})?)\s*[xX]""")
        val matches = regex.findAll(cleaned).mapNotNull {
            it.groupValues[1].toDoubleOrNull()
        }.filter { it >= 1.0 && it <= 100000000.0 }.toList()

        if (matches.isEmpty()) return

        // If multiple x-values somehow make it through OCR, choose the first.
        // The tuned crop normally contains only the giant live value.
        val candidate = matches.first()
        val now = System.currentTimeMillis()

        if (pendingValue == null || abs(pendingValue!! - candidate) > 0.000001) {
            pendingValue = candidate
            pendingSince = now
            pendingHits = 1
            updateOverlay("Reading… ${fmt(candidate,2)}×")
            return
        }

        pendingHits++

        // A stable displayed value is the result that matters. Commit only
        // after a short stability window, filtering the post-Bet flash cycle.
        if (now - pendingSince >= SETTLE_MS && !sameAsLastCommitted(candidate)) {
            lastCommitted = candidate
            results.add(candidate)
            if (results.size > 1000) results.removeAt(0)
            pendingValue = null
            pendingHits = 0
            updateOverlay()
        }
    }

    private fun sameAsLastCommitted(v: Double) =
        lastCommitted != null && abs(lastCommitted!! - v) < 0.000001

    private fun updateOverlay(status: String? = null) {
        if (results.isEmpty()) {
            overlay?.text = "LIMBO SIGNAL\n${status ?: "Waiting for first result…"}"
            return
        }

        val recent = results.takeLast(min(30, results.size))
        val logs = recent.map { ln(it) }
        val mean = logs.average()
        val sd = if (logs.size > 1) {
            sqrt(logs.map { (it-mean).pow(2) }.average())
        } else 0.0
        val baseline = results.map { ln(it) }.average()
        val z = if (sd > 1e-9) (mean - baseline) / sd else 0.0
        val bigRate = recent.count { it >= 10.0 }.toDouble() / recent.size
        val score = (50 + z * 12 + (bigRate - 0.10) * 100).roundToInt().coerceIn(1,99)

        overlay?.text =
            "LIMBO SIGNAL  $score%\n" +
            "Last: ${fmt(results.last(),2)}×  |  10×+: ${fmt(bigRate*100,1)}%\n" +
            (status ?: "Experimental sequence signal")
    }

    private fun fmt(v: Double, n: Int) =
        String.format(Locale.US, "%.${n}f", v)

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "LIMBO SIGNAL\nReading live multiplier…"
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(215, 15,15,15))
            setPadding(18,12,18,12)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 120
        }
        wm.addView(overlay, params)
    }

    override fun onDestroy() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { recognizer?.close() } catch (_: Exception) {}
        ocrExecutor.shutdownNow()

        overlay?.let {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
