# Limbo Signal 4.0 — tuned for the supplied Limbo screenshots

This build is specifically adapted to the two supplied Chrome screenshots.

### What changed

The large center value is the only OCR target. The capture crop is normalized to
the game-card location visible in the screenshots and the OCR parser requires the
multiplier's `x` suffix.

More importantly, the reader now handles the post-Bet flash cycle:

- It samples the screen repeatedly rather than waiting for a single screenshot.
- A newly detected value is treated as a *candidate*, not immediately as a result.
- The candidate has to remain unchanged for about 260 ms before being committed.
- When the screen rapidly cycles through several values after Bet, those transient
  values are therefore discarded.
- The value that remains displayed is recorded as the official result.
- Repeated frames of the same result are deduplicated.

### Android

The app works with Stake opened in Chrome or Firefox; it does not require the Stake
Android app. Android MediaProjection requires explicit user approval for screen
capture. A floating overlay requires "Display over other apps".

### Build

Open this directory in Android Studio and choose:

Build -> Build APK(s)

APK output:
app/build/outputs/apk/debug/app-debug.apk

The statistical signal remains experimental and is not a guarantee that the next
independent Limbo outcome can be predicted.
